using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using System.Security.Claims;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// 5.2.2 ��������� �������������� � ���������� �������
builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = "GitHub";
})
// 5.2.4 ��������� ��������� Cookie
.AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
{
    options.Cookie.HttpOnly = true;
    options.ExpireTimeSpan = TimeSpan.FromMinutes(60);
    options.SlidingExpiration = true;
})
// 5.2.5 ��������� ��������� OAuth ��� GitHub
.AddOAuth("GitHub", options =>
{
    // 5.2.6 ��������� endpoints � ������������ � ������������� GitHub
    options.AuthorizationEndpoint = "https://github.com/login/oauth/authorize";
    options.TokenEndpoint = "https://github.com/login/oauth/access_token";
    options.UserInformationEndpoint = "https://api.github.com/user";

    options.ClientId = builder.Configuration["GitHub:ClientId"];
    options.ClientSecret = builder.Configuration["GitHub:ClientSecret"];
    options.CallbackPath = new PathString("/signin-github");

    options.SaveTokens = true;

    // 5.2.7 ��������� ClaimActions �� ������ ������������ GitHub Users API
    options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "id");
    options.ClaimActions.MapJsonKey(ClaimTypes.Name, "login");
    options.ClaimActions.MapJsonKey(ClaimTypes.Email, "email");
    options.ClaimActions.MapJsonKey("urn:github:name", "name");
    options.ClaimActions.MapJsonKey("urn:github:avatar_url", "avatar_url");
    options.ClaimActions.MapJsonKey("urn:github:html_url", "html_url");
    options.ClaimActions.MapJsonKey("urn:github:company", "company");
    options.ClaimActions.MapJsonKey("urn:github:blog", "blog");
    options.ClaimActions.MapJsonKey("urn:github:location", "location");
    options.ClaimActions.MapJsonKey("urn:github:bio", "bio");
    options.ClaimActions.MapJsonKey("urn:github:twitter_username", "twitter_username");
    options.ClaimActions.MapJsonKey("urn:github:public_repos", "public_repos");
    options.ClaimActions.MapJsonKey("urn:github:followers", "followers");
    options.ClaimActions.MapJsonKey("urn:github:following", "following");
    options.ClaimActions.MapJsonKey("urn:github:created_at", "created_at");
    options.ClaimActions.MapJsonKey("urn:github:updated_at", "updated_at");

    options.Events = new OAuthEvents
    {
        OnCreatingTicket = async context =>
        {
            // ������ � GitHub API ��� ��������� ���������� � ������������
            var request = new HttpRequestMessage(HttpMethod.Get, context.Options.UserInformationEndpoint);
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", context.AccessToken);
            request.Headers.UserAgent.ParseAdd("UniversityOAuthApp"); // GitHub ������� User-Agent
            request.Headers.Accept.ParseAdd("application/vnd.github.v3+json");

            var response = await context.Backchannel.SendAsync(request, context.HttpContext.RequestAborted);
            response.EnsureSuccessStatusCode();

            var userJson = await response.Content.ReadAsStringAsync();
            using var user = JsonDocument.Parse(userJson);

            // ������������ claims �� ������ GitHub
            context.RunClaimActions(user.RootElement);
        },
        OnRemoteFailure = context =>
        {
            context.Response.Redirect("/error?failureMessage=" + Uri.EscapeDataString(context.Failure.Message));
            context.HandleResponse();
            return Task.CompletedTask;
        }
    };
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();