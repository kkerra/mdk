﻿namespace GitHubOAuthWebApi.Models
{
    public class GitHubOAuthSettings
    {
        public string ClientId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
    }

}
