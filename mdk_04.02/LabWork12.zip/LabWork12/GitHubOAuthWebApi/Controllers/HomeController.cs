﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class HomeController : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public IActionResult Get()
    {
        var isAuthenticated = HttpContext.User.Identity?.IsAuthenticated ?? false;

        var endpoints = new
        {
            authentication = new
            {
                login = "/api/auth/login",
                logout = "/api/auth/logout",
                status = "/api/auth/status",
                user_info = "/api/auth/user-info"
            },
            user_data = new
            {
                profile = "/api/user/profile",
                repos_info = "/api/user/repos"
            },
            current_status = new
            {
                is_authenticated = isAuthenticated,
                user = isAuthenticated ? HttpContext.User.Identity.Name : "Anonymous"
            }
        };

        return Ok(endpoints);
    }

    [HttpGet("public")]
    [AllowAnonymous]
    public IActionResult GetPublicInfo()
    {
        return Ok(new
        {
            Message = "This is public information available to everyone",
            ServerTime = DateTime.Now,
            Application = "University OAuth Demo"
        });
    }

    [HttpGet("protected")]
    [Authorize]
    public IActionResult GetProtectedInfo()
    {
        return Ok(new
        {
            Message = "This is protected information available only to authenticated users",
            User = HttpContext.User.Identity.Name,
            AccessedAt = DateTime.Now
        });
    }
}