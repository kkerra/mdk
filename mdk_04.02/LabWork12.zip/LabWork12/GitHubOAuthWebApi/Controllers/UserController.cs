﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    [HttpGet("profile")]
    [Authorize]
    public IActionResult GetUserProfile()
    {
        var user = HttpContext.User;

        return Ok(new
        {
            Message = $"Hello, {user.FindFirst(ClaimTypes.Name)?.Value}!",
            GitHubProfile = user.FindFirst("urn:github:html_url")?.Value,
            Avatar = user.FindFirst("urn:github:avatar_url")?.Value,
            Bio = user.FindFirst("urn:github:bio")?.Value,
            AuthenticatedAt = DateTime.Now
        });
    }

    [HttpGet("repos")]
    [Authorize]
    public IActionResult GetUserReposInfo()
    {
        var user = HttpContext.User;
        var publicRepos = user.FindFirst("urn:github:public_repos")?.Value;
        var followers = user.FindFirst("urn:github:followers")?.Value;
        var following = user.FindFirst("urn:github:following")?.Value;

        return Ok(new
        {
            Username = user.FindFirst(ClaimTypes.Name)?.Value,
            PublicRepositories = publicRepos,
            Followers = followers,
            Following = following,
            GitHubStats = new
            {
                ProfileCreated = user.FindFirst("urn:github:created_at")?.Value,
                LastUpdated = user.FindFirst("urn:github:updated_at")?.Value
            }
        });
    }
}