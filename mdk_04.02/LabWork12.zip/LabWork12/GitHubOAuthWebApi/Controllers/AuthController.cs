﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
   
    // GET /api/auth/login-redirect
    [HttpGet("login")]
    [AllowAnonymous]
    public IActionResult LoginRedirect([FromQuery] string returnUrl = "/api/auth/user-info")
    {
        return Challenge(new AuthenticationProperties
        {
            RedirectUri = returnUrl
        }, "GitHub");
    }

    // GET /api/auth/user-info
    [HttpGet("user-info")]
    [Authorize]
    public IActionResult GetUserInfo()
    {
        var user = HttpContext.User;

        var userInfo = new
        {
            IsAuthenticated = user.Identity?.IsAuthenticated,
            Username = user.FindFirst(ClaimTypes.Name)?.Value,
            GitHubId = user.FindFirst(ClaimTypes.NameIdentifier)?.Value,
            Email = user.FindFirst(ClaimTypes.Email)?.Value,
            FullName = user.FindFirst("urn:github:name")?.Value,
            ProfileUrl = user.FindFirst("urn:github:html_url")?.Value,
            AvatarUrl = user.FindFirst("urn:github:avatar_url")?.Value,
            Company = user.FindFirst("urn:github:company")?.Value,
            Location = user.FindFirst("urn:github:location")?.Value,
            Message = "Successfully authenticated with GitHub! 🎉",
            AuthenticatedAt = DateTime.Now
        };

        return Ok(userInfo);
    }

    // POST /api/auth/logout
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Ok(new { message = "Successfully logged out" });
    }

    // GET /api/auth/status
    [HttpGet("status")]
    [AllowAnonymous]
    public IActionResult GetAuthStatus()
    {
        var isAuthenticated = HttpContext.User.Identity?.IsAuthenticated ?? false;
        return Ok(new
        {
            IsAuthenticated = isAuthenticated,
            UserName = isAuthenticated ? HttpContext.User.Identity.Name : null,
            Timestamp = DateTime.Now
        });
    }

    private bool IsApiRequest()
    {
        return Request.Headers.ContainsKey("X-Requested-With") ||
               (Request.Headers.Accept.Any(a => a.Contains("application/json")) &&
                !Request.Headers.UserAgent.Any(u => u.Contains("Mozilla")));
    }
}