﻿using LabWork12.WebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly List<User> _users;
    private readonly JwtSettings _jwtSettings;

    public AuthController(List<User> users, JwtSettings jwtSettings)
    {
        _users = users;
        _jwtSettings = jwtSettings;
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        Console.WriteLine($"Login attempt for: {request.Username}");

        var user = _users.FirstOrDefault(u =>
            u.Username == request.Username && u.Password == request.Password);

        if (user == null)
        {
            Console.WriteLine("Login failed: invalid credentials");
            return Unauthorized("Неверные учетные данные");
        }

        try
        {
            // Создание токена
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwtSettings.Key);

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(JwtRegisteredClaimNames.Sub, user.Username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString(), ClaimValueTypes.Integer64)
            };

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddMinutes(_jwtSettings.AccessTokenExpirationMinutes),
                Issuer = _jwtSettings.Issuer,
                Audience = _jwtSettings.Audience,
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return Ok(new LoginResponse
            {
                Token = tokenString,
                TokenType = "Bearer",
                Username = user.Username,
                Role = user.Role,
                ExpiresIn = _jwtSettings.AccessTokenExpirationMinutes * 60,
                ExpiresAt = DateTime.UtcNow.AddMinutes(_jwtSettings.AccessTokenExpirationMinutes)
            });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Token creation error: {ex.Message}");
            return StatusCode(500, "Ошибка при создании токена");
        }
    }

    [HttpGet("test-users")]
    public IActionResult GetTestUsers()
    {
        var users = _users.Select(u => new { u.Username, u.Role, u.Password });
        return Ok(users);
    }
}