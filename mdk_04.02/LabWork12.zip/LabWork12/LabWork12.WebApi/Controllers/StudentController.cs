﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

[ApiController]
[Route("api/[controller]")]
public class StudentController : ControllerBase
{
    [HttpGet("grades")]
    [Authorize(Roles = "Student,Teacher,Administrator")]
    public IActionResult GetGrades()
    {
        var userName = User.Identity?.Name;
        var userRole = User.FindFirst(ClaimTypes.Role)?.Value;

        Console.WriteLine($"Accessing grades - User: {userName}, Role: {userRole}");

        return Ok(new
        {
            Message = $"Пользователь {userName} (роль: {userRole}), вот ваши оценки",
            User = userName,
            Role = userRole,
            Grades = new[] { "Математика: 5", "Физика: 4", "Программирование: 5" },
            AccessedAt = DateTime.Now
        });
    }

    [HttpGet("schedule")]
    [Authorize(Roles = "Student")]
    public IActionResult GetSchedule()
    {
        var userName = User.Identity?.Name;

        return Ok(new
        {
            Message = $"Студент {userName}, вот ваше расписание",
            Schedule = new[] { "Пн: Математика 9:00", "Вт: Программирование 11:00" },
            AccessedAt = DateTime.Now
        });
    }

    [HttpGet("profile")]
    [Authorize]
    public IActionResult GetProfile()
    {
        var claims = User.Claims.Select(c => new { c.Type, c.Value }).ToList();

        return Ok(new
        {
            UserName = User.Identity?.Name,
            Role = User.FindFirst(ClaimTypes.Role)?.Value,
            Claims = claims,
            IsAuthenticated = User.Identity?.IsAuthenticated
        });
    }
}