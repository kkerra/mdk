﻿using System;
using System.Security.Principal;
using System.Windows;
using System.Windows.Media;

namespace WindowsAuthApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DisplayUserInfo();
        }

        private void DisplayUserInfo()
        {
            WindowsIdentity currentUser = WindowsIdentity.GetCurrent();
            WindowsPrincipal userPrincipal = new WindowsPrincipal(currentUser);

            tbUserName.Text = "Имя пользователя: " + currentUser.Name;
            tbDomain.Text = "Домен: " + (currentUser.Name.Contains("\\") ? currentUser.Name.Split('\\')[0] : "Локальный компьютер");
            tbAuthenticationType.Text = "Тип аутентификации: " + currentUser.AuthenticationType;
        }

        private void btnCheckAdmin_Click(object sender, RoutedEventArgs e)
        {
            WindowsIdentity currentUser = WindowsIdentity.GetCurrent();
            WindowsPrincipal userPrincipal = new WindowsPrincipal(currentUser);

            bool isAdmin = userPrincipal.IsInRole(WindowsBuiltInRole.Administrator);

            if (isAdmin)
            {
                tbAuthorizationResult.Text = "Успех: Пользователь является администратором.";
                tbAuthorizationResult.Foreground = Brushes.Green;
                btnShowSecret.IsEnabled = true;
            }
            else
            {
                tbAuthorizationResult.Text = "Ошибка: Пользователь НЕ является администратором.";
                tbAuthorizationResult.Foreground = Brushes.Red;
                btnShowSecret.IsEnabled = false;
            }
        }

        private void btnShowSecret_Click(object sender, RoutedEventArgs e)
        {
            tbSecretData.Text = "Доступ к сверхсекретным данным разрешен!\n\n" +
                                "Конфиденциальная информация:\n" +
                                "1. Я смотрю аниме.\n" +
                                "2. Герасименко Степан Евгеньевич был замечен в 01:34 у местного Бристоля.\n" +
                                "3. Ежи - шпионы инопланетян.\n" +
                                "4. Йогурт Чюдо на самом деле не 8 чюдо света";
        }
    }
}