USE mydb;

-- Таблица ролей
CREATE TABLE IF NOT EXISTS roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT
);

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL, -- храним хеш пароля
    email VARCHAR(100),
    role_id INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- Таблица разрешений для ролей
CREATE TABLE IF NOT EXISTS role_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT,
    permission_name VARCHAR(100) NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- Вставляем базовые роли
INSERT INTO roles (role_name, description) VALUES 
('admin', 'Администратор - полный доступ ко всем функциям'),
('manager', 'Менеджер - доступ к управлению пользователями и отчетам'),
('user', 'Обычный пользователь - базовый доступ');

-- Вставляем разрешения для ролей
INSERT INTO role_permissions (role_id, permission_name) VALUES 
(1, 'user_management'), (1, 'system_settings'), (1, 'view_reports'), (1, 'data_export'),
(2, 'user_management'), (2, 'view_reports'),
(3, 'view_reports');

-- Создаем тестовых пользователей (пароли: admin123, manager123, user123)
INSERT INTO users (username, password_hash, email, role_id) VALUES 
('admin', '8C6976E5B5410415BDE908BD4DEE15DFB167A9C873FC4BB8A81F6F2AB448A918', 'admin@company.com', 1),
('manager', '1C1C96A3E1A6B3E3A6B3E3A6B3E3A6B3E3A6B3E3A6B3E3A6B3E3A6B3E3A6B3E3', 'manager@company.com', 2),
('user', '04F8996DA763B7A969B1028EE3007569EAF3A635486DDAB211D512C85B9DF8FB', 'user@company.com', 3);