﻿using System;
using System.Windows;
using System.Windows.Controls;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace DBAuthApp
{
    public partial class MainWindow : Window
    {
        private string connectionString = "Server=127.0.0.1;Port=3306;Database=mydb;Uid=root;Pwd=root;";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ShowError("Введите логин и пароль");
                return;
            }

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"
                        SELECT u.*, r.role_name 
                        FROM users u 
                        JOIN roles r ON u.role_id = r.id 
                        WHERE u.username = @username AND u.password = @password";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string role = reader["role_name"].ToString();
                                ShowUserInterface(username, role);
                            }
                            else
                            {
                                ShowError("Неверный логин или пароль");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка: {ex.Message}");
            }
        }

        private void ShowUserInterface(string username, string role)
        {
            loginPanel.Visibility = Visibility.Collapsed;
            mainPanel.Visibility = Visibility.Visible;

            txtWelcome.Text = $"Добро пожаловать, {username}!";
            txtRoleInfo.Text = $"Ваша роль: {GetRoleDescription(role)}";

            permissionsPanel.Children.Clear();
            AddPermissions(role);
        }

        private string GetRoleDescription(string role)
        {
            return role switch
            {
                "admin" => "Администратор системы",
                "manager" => "Менеджер",
                "user" => "Обычный пользователь",
                _ => "Неизвестная роль"
            };
        }

        private void AddPermissions(string role)
        {
            var permissions = GetPermissionsForRole(role);

            foreach (var permission in permissions)
            {
                var textBlock = new TextBlock
                {
                    Text = $"• {permission}",
                    FontSize = 14,
                    Margin = new Thickness(0, 2, 0, 2),
                    Foreground = System.Windows.Media.Brushes.DarkSlateGray
                };

                permissionsPanel.Children.Add(textBlock);
            }
        }

        private List<string> GetPermissionsForRole(string role)
        {
            var permissions = new List<string>();

            switch (role)
            {
                case "admin":
                    permissions.Add("Просмотр всех данных системы");
                    permissions.Add("Управление пользователями");
                    permissions.Add("Изменение системных настроек");
                    permissions.Add("Просмотр логов и отчетов");
                    permissions.Add("Резервное копирование данных");
                    break;

                case "manager":
                    permissions.Add("Просмотр отчетов и статистики");
                    permissions.Add("Управление клиентами");
                    permissions.Add("Создание и редактирование заказов");
                    permissions.Add("Просмотр финансовых данных");
                    break;

                case "user":
                    permissions.Add("Просмотр личных данных");
                    permissions.Add("Изменение своего профиля");
                    permissions.Add("Просмотр общей информации");
                    permissions.Add("Создание заявок и обращений");
                    break;
            }

            return permissions;
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            mainPanel.Visibility = Visibility.Collapsed;
            loginPanel.Visibility = Visibility.Visible;

            txtLogin.Clear();
            txtPassword.Clear();
            txtError.Visibility = Visibility.Collapsed;
        }

        private void ShowError(string message)
        {
            txtError.Text = message;
            txtError.Visibility = Visibility.Visible;
        }
    }
}