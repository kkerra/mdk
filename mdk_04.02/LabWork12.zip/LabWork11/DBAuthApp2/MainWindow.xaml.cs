﻿using Microsoft.Win32;
using MySql.Data.MySqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Controls;

namespace DBAuthApp2
{
    public partial class MainWindow : Window
    {
        private string connectionString = "Server=127.0.0.1;Port=3306;Database=mydb;Uid=root;Pwd=root;";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnShowRegister_Click(object sender, RoutedEventArgs e)
        {
            loginPanel.Visibility = Visibility.Collapsed;
            registerPanel.Visibility = Visibility.Visible;
        }

        private void btnBackToLogin_Click(object sender, RoutedEventArgs e)
        {
            registerPanel.Visibility = Visibility.Collapsed;
            loginPanel.Visibility = Visibility.Visible;
            txtRegStatus.Visibility = Visibility.Collapsed;
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            string username = txtRegLogin.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {
                ShowRegStatus("Введите имя", true);
                return;
            }

            try
            {
                // Генерация RSA ключей
                using (var rsa = RSA.Create(2048))
                {
                    // Экспорт ключей
                    byte[] publicKey = rsa.ExportRSAPublicKey();
                    byte[] privateKey = rsa.ExportRSAPrivateKey();

                    // Генерация тестового токена
                    byte[] testToken = RandomNumberGenerator.GetBytes(32);

                    // Шифрование токена публичным ключом
                    rsa.ImportRSAPublicKey(publicKey, out _);
                    byte[] encryptedToken = rsa.Encrypt(testToken, RSAEncryptionPadding.Pkcs1);

                    // Сохранение приватного ключа в файл
                    string keyFileName = $"{username}_private_key.key";
                    File.WriteAllBytes(keyFileName, privateKey);

                    // Сохранение пользователя в базу
                    SaveUserToDatabase(username, publicKey, encryptedToken);

                    ShowRegStatus($"Регистрация успешна!\nПриватный ключ сохранен в: {keyFileName}\n\nСохраните этот файл в безопасном месте!", false);

                    txtRegLogin.Clear();
                }
            }
            catch (Exception ex)
            {
                ShowRegStatus($"Ошибка регистрации: {ex.Message}", true);
            }
        }

        private void SaveUserToDatabase(string username, byte[] publicKey, byte[] encryptedToken)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                var roleItem = cmbRole.SelectedItem as ComboBoxItem;
                int roleId = int.Parse(roleItem.Tag.ToString());

                string query = @"
                    INSERT INTO users (username, role_id, public_key, encrypted_token) 
                    VALUES (@username, @role_id, @public_key, @encrypted_token)";

                using (var cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@role_id", roleId);
                    cmd.Parameters.AddWithValue("@public_key", publicKey);
                    cmd.Parameters.AddWithValue("@encrypted_token", encryptedToken);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void btnBrowseKey_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "Key files (*.key)|*.key|All files (*.*)|*.*",
                Title = "Выберите файл приватного ключа"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                txtKeyPath.Text = openFileDialog.FileName;
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtLogin.Text.Trim();
            string keyPath = txtKeyPath.Text;

            if (string.IsNullOrEmpty(username) || !File.Exists(keyPath))
            {
                ShowError("Введите логин и выберите файл ключа");
                return;
            }

            try
            {
                // Загрузка приватного ключа из файла
                byte[] privateKeyBytes = File.ReadAllBytes(keyPath);

                using (var rsa = RSA.Create())
                {
                    rsa.ImportRSAPrivateKey(privateKeyBytes, out _);

                    var userData = GetUserData(username);
                    if (userData == null)
                    {
                        ShowError("Пользователь не найден");
                        return;
                    }

                    byte[] decryptedToken;
                    try
                    {
                        decryptedToken = rsa.Decrypt(userData.EncryptedToken, RSAEncryptionPadding.Pkcs1);
                        ShowUserInterface(userData.Username, userData.Role);
                    }
                    catch (CryptographicException)
                    {
                        ShowError("Неверный приватный ключ для данного пользователя");
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка авторизации: {ex.Message}");
            }
        }

        private UserData GetUserData(string username)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = @"
                    SELECT u.id, u.username, r.role_name, r.id as role_id, 
                           u.public_key, u.encrypted_token 
                    FROM users u 
                    JOIN roles r ON u.role_id = r.id 
                    WHERE u.username = @username";

                using (var cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@username", username);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new UserData
                            {
                                Id = reader.GetInt32("id"),
                                Username = reader.GetString("username"),
                                Role = reader.GetString("role_name"),
                                RoleId = reader.GetInt32("role_id"),
                                PublicKey = (byte[])reader["public_key"],
                                EncryptedToken = (byte[])reader["encrypted_token"]
                            };
                        }
                    }
                }
            }
            return null;
        }

        private void ShowUserInterface(string username, string role)
        {
            loginPanel.Visibility = Visibility.Collapsed;
            mainPanel.Visibility = Visibility.Visible;

            txtWelcome.Text = $"Добро пожаловать, {username}!";
            txtRoleInfo.Text = $"Ваша роль: {GetRoleDescription(role)}";
            txtRSAInfo.Text = $"Метод аутентификации: RSA-2048\nПриватный ключ: загружен из файла";

            permissionsPanel.Children.Clear();
            AddPermissions(role);
        }

        private string GetRoleDescription(string role)
        {
            return role switch
            {
                "admin" => "Администратор системы",
                "manager" => "Менеджер",
                "user" => "Обычный пользователь",
                _ => "Неизвестная роль"
            };
        }

        private void AddPermissions(string role)
        {
            var permissions = GetPermissionsForRole(role);

            foreach (var permission in permissions)
            {
                var textBlock = new TextBlock
                {
                    Text = $"• {permission}",
                    FontSize = 14,
                    Margin = new Thickness(0, 2, 0, 2),
                    Foreground = System.Windows.Media.Brushes.DarkSlateGray
                };

                permissionsPanel.Children.Add(textBlock);
            }
        }

        private List<string> GetPermissionsForRole(string role)
        {
            var permissions = new List<string>();

            switch (role)
            {
                case "admin":
                    permissions.Add("Просмотр всех данных системы");
                    permissions.Add("Управление пользователями");
                    permissions.Add("Изменение системных настроек");
                    permissions.Add("Просмотр логов и отчетов");
                    permissions.Add("Резервное копирование данных");
                    break;

                case "manager":
                    permissions.Add("Просмотр отчетов и статистики");
                    permissions.Add("Управление клиентами");
                    permissions.Add("Создание и редактирование заказов");
                    permissions.Add("Просмотр финансовых данных");
                    break;

                case "user":
                    permissions.Add("Просмотр личных данных");
                    permissions.Add("Изменение своего профиля");
                    permissions.Add("Просмотр общей информации");
                    permissions.Add("Создание заявок и обращений");
                    break;
            }

            return permissions;
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            mainPanel.Visibility = Visibility.Collapsed;
            loginPanel.Visibility = Visibility.Visible;

            txtLogin.Clear();
            txtKeyPath.Text = "Выберите файл ключа...";
            txtError.Visibility = Visibility.Collapsed;
        }

        private void ShowError(string message)
        {
            txtError.Text = message;
            txtError.Visibility = Visibility.Visible;
        }

        private void ShowRegStatus(string message, bool isError)
        {
            txtRegStatus.Text = message;
            txtRegStatus.Foreground = isError ? System.Windows.Media.Brushes.Red : System.Windows.Media.Brushes.Blue;
            txtRegStatus.Visibility = Visibility.Visible;
        }
    }

    public class UserData
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public int RoleId { get; set; }
        public byte[] PublicKey { get; set; }
        public byte[] EncryptedToken { get; set; }
    }
}